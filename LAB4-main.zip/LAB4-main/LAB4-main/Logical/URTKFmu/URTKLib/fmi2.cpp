/********************************************************************
 * COPYRIGHT -- B&R Industrial Automation GmbH
 ********************************************************************
 * Program: fmu
 * File: fmu.cpp
 * Author: hkellinger
 * Created: June 25, 2015
 ********************************************************************
 * Basic fmu declarations
 ********************************************************************/

#ifdef __cplusplus
unsigned long bur_heap_size = 4096000;
#endif



